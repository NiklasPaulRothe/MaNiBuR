#!/bin/bash

echo 'Skript zum Laden der brpa3_959042_959218.ko gestartet'
insmod brpa3_959042_959218.ko
echo 'Skript zum Laden der brpa3_959042_959218.ko beendet'